plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.danzstraight.inject"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.danzstraight.inject"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-DANZSTRAIGHT"
        setProperty("archivesBaseName", "DANZSTRAIGHT")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
