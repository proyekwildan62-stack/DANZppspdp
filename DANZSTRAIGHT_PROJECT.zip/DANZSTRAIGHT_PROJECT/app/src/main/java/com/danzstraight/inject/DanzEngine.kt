package com.danzstraight.inject

object DanzEngine {
    const val PKG_FF_TH = "com.dts.freefireth"
    const val PKG_FF_MAX = "com.dts.freefiremax"

    fun cmdsDragHs(pkg: String) = listOf(
        "settings put system pointer_speed 7",
        "settings put secure long_press_timeout 200",
        "settings put secure multi_press_timeout 150",
        "cmd device_config put input_native_boot velocitytracker_strategy impulse",
        "setprop debug.input.VelocityTracker.strategy impulse",
        "setprop persist.sys.scrollingcache 3"
    )
    fun cmdsAimSmooth() = listOf(
        "setprop debug.sf.latch_unsignaled 1",
        "setprop debug.sf.disable_backpressure 1",
        "setprop debug.sf.early_phase_offset_ns 500000",
        "cmd device_config put surface_flinger_native_boot max_frame_buffer_acquired_buffers 3"
    )
    fun cmdsHeadlock() = listOf(
        "settings put secure tap_duration_threshold 0.0",
        "settings put secure touch_exploration_enabled 0",
        "setprop debug.input.resample 1",
        "cmd device_config put input_native_boot deep_press_enabled false"
    )
    fun cmdsHeadtrik(pkg: String) = listOf(
        "cmd game set --mode 2 --downscale disable $pkg",
        "cmd game mode performance $pkg",
        "setprop debug.hwui.overdraw false"
    )
    fun cmdsAimtrick(pkg: String) = listOf(
        "setprop debug.performance.tuning 1",
        "setprop video.accelerate.hw 1",
        "cmd device_config put input_native_boot pointer_choreographer_enabled true",
        "FF_PID=\$(pidof $pkg); if [ -n \"\$FF_PID\" ]; then renice -n -20 -p \$FF_PID; fi"
    )
    fun cmdsBoostPerformance(pkg: String) = listOf(
        "cmd power set-fixed-performance-mode-enabled true",
        "settings put global window_animation_scale 0.0",
        "settings put global transition_animation_scale 0.0",
        "settings put global animator_duration_scale 0.0",
        "cmd package compile -m speed -f $pkg",
        "am send-trim-memory $pkg RUNNING_LOW"
    )
    fun cmdsTouchPelicin() = listOf(
        "settings put system peak_refresh_rate 120.0",
        "settings put system min_refresh_rate 120.0",
        "setprop debug.sf.frame_rate_multiple_threshold 120"
    )
    fun cmdsRestoreDefaults(pkg: String) = listOf(
        "cmd power set-fixed-performance-mode-enabled false",
        "settings put system pointer_speed 0",
        "settings put global window_animation_scale 1.0",
        "settings put global transition_animation_scale 1.0",
        "settings put global animator_duration_scale 1.0",
        "cmd game reset $pkg"
    )
}
