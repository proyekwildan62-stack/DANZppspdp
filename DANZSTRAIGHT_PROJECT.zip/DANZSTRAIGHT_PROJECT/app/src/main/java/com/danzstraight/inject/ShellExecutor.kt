package com.danzstraight.inject
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShellExecutor {
    enum class Mode { ROOT, SHIZUKU, NONE }

    fun detectPrivilegeMode(): Mode {
        try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id -u"))
            if (BufferedReader(InputStreamReader(p.inputStream)).readLine()?.trim() == "0") return Mode.ROOT
        } catch (_: Throwable) {}
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) return Mode.SHIZUKU
                else Shizuku.requestPermission(1001)
            }
        } catch (_: Throwable) {}
        return Mode.NONE
    }

    fun execBatch(cmds: List<String>): Pair<Boolean, String> {
        val mode = detectPrivilegeMode()
        if (mode == Mode.NONE) return Pair(false, "Aktifkan & izinkan Shizuku / Root terlebih dahulu!")
        val joined = cmds.joinToString(" ; ")
        return try {
            val proc = if (mode == Mode.ROOT) Runtime.getRuntime().exec(arrayOf("su", "-c", joined))
            else {
                val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
                m.isAccessible = true
                m.invoke(null, arrayOf("sh", "-c", joined), null, null) as Process
            }
            Pair(proc.waitFor() == 0, "OK ($mode)")
        } catch (e: Throwable) { Pair(false, e.message ?: "Error") }
    }
}
