package com.danzstraight.inject
import android.content.Context
import android.os.Build
import android.provider.Settings
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object LicenseCrypto {
    private const val MASTER_SALT = "DANZSTRAIGHT_CORE_HMAC_2026_V1_MASTER_KEY"
    val DURATION_SECONDS = mapOf("1D" to 86400L, "3D" to 259200L, "7D" to 604800L, "15D" to 1296000L, "30D" to 2592000L, "PERM" to 3153600000L)

    fun getDeviceHwid(ctx: Context): String {
        val aid = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "0"
        return hmacSha256("${aid}_${Build.BOARD}", "HWID_BIND").take(14).uppercase()
    }

    private fun hmacSha256(data: String, key: String = MASTER_SALT): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key.toByteArray(), "HmacSHA256"))
        return mac.doFinal(data.toByteArray()).joinToString("") { "%02X".format(it) }
    }

    fun generateKey(hwid: String, tier: String, role: String): String {
        val h = hwid.trim().uppercase()
        val t = tier.trim().uppercase()
        val r = role.trim().uppercase()
        val exp = (System.currentTimeMillis() / 1000L) + (DURATION_SECONDS[t] ?: 86400L)
        val sig = hmacSha256("$h|$exp|$t|$r").take(12)
        return "DANZ-$t-$exp-$r-$sig"
    }

    data class VerifyResult(val valid: Boolean, val tier: String = "", val role: String = "", val remainingDays: Long = 0, val errorMsg: String = "")

    fun verifyKeyForDevice(key: String, localHwid: String): VerifyResult {
        val p = key.trim().uppercase().split("-")
        if (p.size != 5 || p[0] != "DANZ") return VerifyResult(false, errorMsg = "Format Key salah!")
        val exp = p[2].toLongOrNull() ?: return VerifyResult(false, errorMsg = "Timestamp rusak!")
        val expected = hmacSha256("${localHwid.trim().uppercase()}|$exp|${p[1]}|${p[3]}").take(12)
        if (p[4] != expected) return VerifyResult(false, errorMsg = "1-Key 1-Device: Terkunci di HWID lain!")
        val now = System.currentTimeMillis() / 1000L
        if (now >= exp) return VerifyResult(false, errorMsg = "Key sudah EXPIRED!")
        return VerifyResult(true, p[1], p[3], (exp - now) / 86400L)
    }

    fun verifyDeveloperPin(pin: String): Boolean = pin.trim() == "DANZ-DEV-2026"
}
