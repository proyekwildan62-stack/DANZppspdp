package com.danzstraight.inject
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var localHwid: String
    private var activeRole = "NONE"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val prefs = getSharedPreferences("danzstraight_prefs", Context.MODE_PRIVATE)
        localHwid = LicenseCrypto.getDeviceHwid(this)

        val tvHwid = findViewById<TextView>(R.id.tvHwid)
        val tvPrivilege = findViewById<TextView>(R.id.tvPrivilege)
        val tvLicenseInfo = findViewById<TextView>(R.id.tvLicenseInfo)
        val etLicenseKey = findViewById<EditText>(R.id.etLicenseKey)
        val layoutFeatures = findViewById<LinearLayout>(R.id.layoutFeatures)

        tvHwid.text = "DEVICE HWID: $localHwid (Tap Copy)"
        tvHwid.setOnClickListener { copy("HWID", localHwid); Toast.makeText(this, "HWID Copied!", Toast.LENGTH_SHORT).show() }
        tvPrivilege.text = "ENGINE MODE: ${ShellExecutor.detectPrivilegeMode()} (SDK ${android.os.Build.VERSION.SDK_INT})"

        val saved = prefs.getString("saved_key", "") ?: ""
        if (saved.isNotEmpty()) {
            val r = LicenseCrypto.verifyKeyForDevice(saved, localHwid)
            if (r.valid) { activeRole = r.role; tvLicenseInfo.text = "ACTIVE (${r.tier} | ${r.remainingDays}d)"; layoutFeatures.visibility = View.VISIBLE; etLicenseKey.setText(saved) }
        }

        findViewById<Button>(R.id.btnVerifyKey).setOnClickListener {
            val k = etLicenseKey.text.toString().trim()
            val r = LicenseCrypto.verifyKeyForDevice(k, localHwid)
            if (r.valid) {
                prefs.edit().putString("saved_key", k).apply()
                activeRole = r.role
                tvLicenseInfo.text = "ACTIVE (${r.tier} | ${r.remainingDays}d)"
                layoutFeatures.visibility = View.VISIBLE
            } else Toast.makeText(this, r.errorMsg, Toast.LENGTH_LONG).show()
        }

        val rbFfOrig = findViewById<RadioButton>(R.id.rbFfOrig)
        findViewById<Button>(R.id.btnInjectLaunch).setOnClickListener {
            val pkg = if (rbFfOrig.isChecked) DanzEngine.PKG_FF_TH else DanzEngine.PKG_FF_MAX
            val b = mutableListOf<String>()
            if (findViewById<Switch>(R.id.swDragHs).isChecked) b.addAll(DanzEngine.cmdsDragHs(pkg))
            if (findViewById<Switch>(R.id.swAimSmooth).isChecked) b.addAll(DanzEngine.cmdsAimSmooth())
            if (findViewById<Switch>(R.id.swHeadlock).isChecked) b.addAll(DanzEngine.cmdsHeadlock())
            if (findViewById<Switch>(R.id.swHeadtrik).isChecked) b.addAll(DanzEngine.cmdsHeadtrik(pkg))
            if (findViewById<Switch>(R.id.swAimtrick).isChecked) b.addAll(DanzEngine.cmdsAimtrick(pkg))
            if (findViewById<Switch>(R.id.swBoostPerf).isChecked) b.addAll(DanzEngine.cmdsBoostPerformance(pkg))
            if (findViewById<Switch>(R.id.swTouchPelicin).isChecked) b.addAll(DanzEngine.cmdsTouchPelicin())
            if (b.isEmpty()) return@setOnClickListener
            b.add("monkey -p $pkg -c android.intent.category.LAUNCHER 1")
            Thread { val (_, msg) = ShellExecutor.execBatch(b); runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() } }.start()
        }

        findViewById<Button>(R.id.btnRestoreStock).setOnClickListener {
            val pkg = if (rbFfOrig.isChecked) DanzEngine.PKG_FF_TH else DanzEngine.PKG_FF_MAX
            Thread { val (_, msg) = ShellExecutor.execBatch(DanzEngine.cmdsRestoreDefaults(pkg)); runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() } }.start()
        }

        val sp = findViewById<Spinner>(R.id.spDuration)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("1D", "3D", "7D", "15D", "30D", "PERM", "RESELLER-30D", "RESELLER-PERM"))
        findViewById<Button>(R.id.btnGenerateKey).setOnClickListener {
            val isDev = LicenseCrypto.verifyDeveloperPin(findViewById<EditText>(R.id.etDevPin).text.toString())
            if (!isDev && activeRole != "RESELLER" && activeRole != "DEV") { Toast.makeText(this, "PIN Dev / Key Reseller diperlukan!", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val hwid = findViewById<EditText>(R.id.etTargetHwid).text.toString().trim()
            if (hwid.length < 8) return@setOnClickListener
            val sel = sp.selectedItem.toString()
            val key = if (sel.startsWith("RESELLER")) LicenseCrypto.generateKey(hwid, sel.substringAfter("-"), "RESELLER") else LicenseCrypto.generateKey(hwid, sel, if (isDev) "DEV" else "USER")
            findViewById<TextView>(R.id.tvGeneratedKeyOut).text = key
            copy("KEY", key)
            Toast.makeText(this, "Key Copied!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copy(l: String, t: String) = (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(l, t))
}
